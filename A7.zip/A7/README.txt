
Link to Multiplication Table on GitHub.io: https://derkl0.github.io/A6/a6.html

Link to my repository: https://github.com/derkl0/derkl0.github.io/tree/master/A6